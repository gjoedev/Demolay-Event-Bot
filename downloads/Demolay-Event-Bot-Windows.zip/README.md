# Demolay Event Bot

# Documenation
https://1drv.ms/w/s!ArXnJdAp_FG1hvRZzKuX1keBNcthzA?e=5zOn43
